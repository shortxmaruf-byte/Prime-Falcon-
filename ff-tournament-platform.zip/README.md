# FF Tournament — Free Fire Slot Booking

বাংলা-ভিত্তিক Gaming Dark টুর্নামেন্ট বুকিং সাইট ও আলাদা অ্যাডমিন প্যানেল। এতে আছে:
- Free Fire টুর্নামেন্ট লিস্ট, এন্ট্রি ফি, প্রাইজ পুল, ইভেন্টের সময় ও স্লটের অবস্থা
- প্লেয়ার বুকিং ফর্ম: নাম, UID, যোগাযোগ, bKash/Nagad, প্রেরকের নম্বর ও TrxID
- বুকিং কোড দিয়ে স্ট্যাটাস দেখা
- আলাদা `/admin` লগইন, বুকিং/পেমেন্ট যাচাই, কনফার্ম/বাতিল, টুর্নামেন্ট CRUD এবং সাইট সেটিংস
- SQLite ডেটাবেসে স্লটের unique constraint এবং transaction দিয়ে একই স্লট একাধিকবার বুক হওয়া ঠেকানো
- বাতিল বুকিংয়ের স্লট আবার খালি হয়

## 1. প্রয়োজন
Node.js 20 বা তার নতুন সংস্করণ এবং npm।

## 2. লোকালি চালু করা
```bash
npm install
cp .env.example .env
```
`.env` ফাইলে `SESSION_SECRET`, অ্যাডমিনের পাসওয়ার্ড হ্যাশ এবং নিজের আসল bKash/Nagad নম্বর দিন। পাসওয়ার্ড হ্যাশ বানাতে:
```bash
node -e "require('bcryptjs').hash('Choose-A-Strong-Password', 12).then(console.log)"
```
দেখানো হ্যাশটি `.env`-এর `ADMIN_PASSWORD_HASH`-এ বসান। তারপর:
```bash
npm start
```
সাইট: `http://localhost:3000`  
অ্যাডমিন: `http://localhost:3000/admin`

ডিফল্ট ইউজারনেম `admin` (বা `.env`-এ বদলান)। ডিফল্ট পাসওয়ার্ড নেই; হ্যাশ সেট না করা পর্যন্ত অ্যাডমিন লগইন হবে না।

## 3. অ্যাডমিন কী কী বদলাতে পারবেন
- নতুন টুর্নামেন্ট তৈরি, নাম/মোড/তারিখ/ফি/প্রাইজ/মোট স্লট/বিবরণ/নিয়ম বদলানো
- বুকিংয়ের TrxID এবং প্রেরকের নম্বর দেখে `কনফার্ম` বা `বাতিল` করা
- bKash/Nagad নম্বর, সাইটের নাম ও নোটিশ পরিবর্তন
- বুকিং থাকা টুর্নামেন্ট সরাসরি মুছে না গিয়ে লুকানো হয়, যাতে বুকিংয়ের রেকর্ড থাকে

## 4. ম্যানুয়াল পেমেন্টের নিয়ম
এই সংস্করণ কোনো টাকা নিজে থেকে যাচাই করে না। প্লেয়ার পেমেন্ট করে প্রেরকের নম্বর ও TrxID জমা দেয়; অ্যাডমিন নিজের bKash/Nagad অ্যাকাউন্ট/অফিশিয়াল স্টেটমেন্টে যাচাই করে তারপর কনফার্ম করবে। TrxID লেখা আছে মানেই পেমেন্ট সত্য—এমন ধরে নেবেন না।

## 5. নিরাপত্তা ও প্রোডাকশন
- SQLite ফাইল `data/tournaments.sqlite`-এ থাকে; এটি এবং `.env` ব্যাকআপ রাখুন।
- `SESSION_SECRET`-এ দীর্ঘ random secret দিন; শক্তিশালী admin password ব্যবহার করুন।
- লাইভে HTTPS ব্যবহার করুন এবং `NODE_ENV=production` সেট করুন।
- হোস্টিং-এ persistent disk দরকার, কারণ ephemeral filesystem-এ SQLite ডেটা হারাতে পারে।
- এই starter project-এ email/SMS notification, image upload, team roster, rate limiting, automated gateway integration বা production-grade distributed session store নেই।
- প্রকাশের আগে নিজের সার্ভারে পরীক্ষা করুন, পেমেন্ট নির্দেশনা যাচাই করুন এবং privacy/terms/rules যোগ করুন।

## 6. গুরুত্বপূর্ণ সীমা
এটি সম্পূর্ণ source code-সহ চালানো যায় এমন starter implementation, কিন্তু আপনার হোস্টিং/ডোমেইনে deploy করা হয়নি এবং বাস্তব bKash/Nagad লেনদেন দিয়ে পরীক্ষা করা হয়নি। `.env` কনফিগার করে নিজের সার্ভারে চালু ও যাচাই করতে হবে।
