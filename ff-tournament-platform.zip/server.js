require("dotenv").config();
const express = require("express");
const session = require("express-session");
const helmet = require("helmet");
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const dataDir = path.join(__dirname, "data");
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
const db = new Database(path.join(dataDir, "tournaments.sqlite"));
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
CREATE TABLE IF NOT EXISTS tournaments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  mode TEXT NOT NULL DEFAULT 'Squad (4v4)',
  entry_fee INTEGER NOT NULL DEFAULT 50,
  prize_pool INTEGER NOT NULL DEFAULT 5000,
  event_date TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  rules TEXT NOT NULL DEFAULT 'Cheating is prohibited. Admin decision is final.',
  total_slots INTEGER NOT NULL DEFAULT 48,
  status TEXT NOT NULL DEFAULT 'upcoming',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS slots (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tournament_id INTEGER NOT NULL REFERENCES tournaments(id) ON DELETE CASCADE,
  slot_no INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'available',
  UNIQUE(tournament_id, slot_no)
);
CREATE TABLE IF NOT EXISTS bookings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  booking_code TEXT NOT NULL UNIQUE,
  tournament_id INTEGER NOT NULL REFERENCES tournaments(id),
  slot_no INTEGER NOT NULL,
  player_name TEXT NOT NULL,
  game_uid TEXT NOT NULL,
  contact TEXT NOT NULL,
  payment_method TEXT NOT NULL CHECK(payment_method IN ('bKash','Nagad')),
  sender_number TEXT NOT NULL,
  transaction_id TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','confirmed','rejected')),
  admin_note TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);
`);
const seedCount = db.prepare("SELECT COUNT(*) n FROM tournaments").get().n;
if (!seedCount) {
  const ins = db.prepare(`INSERT INTO tournaments (title,mode,entry_fee,prize_pool,event_date,description,rules,total_slots,status)
    VALUES (?,?,?,?,?,?,?,?,?)`);
  const seed = db.transaction(() => {
    ins.run("Free Fire Squad Cup", "Squad (4v4)", 50, 5000, "2026-11-05T19:00", "একটি প্রতিযোগিতামূলক Free Fire Squad টুর্নামেন্টে অংশ নাও।", "Cheating is prohibited.\nValid game UID is required.\nAdmin decision is final.", 48, "upcoming");
    ins.run("Free Fire Solo Showdown", "Solo", 30, 2500, "2026-11-08T20:00", "Solo players-এর জন্য আলাদা প্রতিযোগিতা।", "Cheating is prohibited.\nAdmin decision is final.", 48, "upcoming");
    for (const t of db.prepare("SELECT id,total_slots FROM tournaments").all()) {
      const slot = db.prepare("INSERT OR IGNORE INTO slots (tournament_id,slot_no,status) VALUES (?,?, 'available')");
      for (let i=1;i<=t.total_slots;i++) slot.run(t.id,i);
    }
  });
  seed();
}
const defaultSettings = {
  site_name: process.env.SITE_NAME || "FF Tournament",
  bkash_number: process.env.BKASH_NUMBER || "01XXXXXXXXX",
  nagad_number: process.env.NAGAD_NUMBER || "01XXXXXXXXX",
  notice: "পেমেন্ট করার আগে টুর্নামেন্টের তথ্য ভালোভাবে দেখে নিন।"
};
const setSetting = db.prepare("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO NOTHING");
for (const [k,v] of Object.entries(defaultSettings)) setSetting.run(k,v);

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "30kb" }));
app.use(express.urlencoded({ extended: false, limit: "30kb" }));
app.use(session({
  name: "ff_admin_session",
  secret: process.env.SESSION_SECRET || "development-only-change-this-secret",
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "strict", secure: process.env.NODE_ENV === "production", maxAge: 1000*60*60*4 }
}));
app.use(express.static(path.join(__dirname, "public")));

const getSettings = () => Object.fromEntries(db.prepare("SELECT key,value FROM settings").all().map(x=>[x.key,x.value]));
const publicTournament = (t) => ({
  ...t,
  filled_slots: db.prepare("SELECT COUNT(*) n FROM slots WHERE tournament_id=? AND status IN ('pending','confirmed')").get(t.id).n,
  available_slots: db.prepare("SELECT COUNT(*) n FROM slots WHERE tournament_id=? AND status='available'").get(t.id).n
});
function adminOnly(req,res,next) {
  if (!req.session.admin) return res.status(401).json({ error: "অ্যাডমিন হিসেবে লগইন করুন।" });
  next();
}
function validText(v,max=120) { return typeof v === "string" && v.trim().length>0 && v.trim().length<=max; }

app.get("/api/config", (req,res) => {
  const s=getSettings();
  res.json({ site_name:s.site_name, bkash_number:s.bkash_number, nagad_number:s.nagad_number, notice:s.notice });
});
app.get("/api/tournaments", (req,res) => {
  const ts=db.prepare("SELECT * FROM tournaments WHERE status!='hidden' ORDER BY event_date ASC").all();
  res.json(ts.map(publicTournament));
});
app.get("/api/tournaments/:id", (req,res) => {
  const t=db.prepare("SELECT * FROM tournaments WHERE id=? AND status!='hidden'").get(Number(req.params.id));
  if (!t) return res.status(404).json({error:"টুর্নামেন্ট পাওয়া যায়নি।"});
  const slots=db.prepare("SELECT slot_no,status FROM slots WHERE tournament_id=? ORDER BY slot_no").all(t.id);
  res.json({ ...publicTournament(t), slots });
});
app.post("/api/bookings", (req,res) => {
  const { tournament_id, slot_no, player_name, game_uid, contact, payment_method, sender_number, transaction_id }=req.body||{};
  if (!Number.isInteger(Number(tournament_id)) || !Number.isInteger(Number(slot_no)) ||
      !validText(player_name,80) || !validText(game_uid,40) || !validText(contact,30) ||
      !["bKash","Nagad"].includes(payment_method) || !validText(sender_number,30) || !validText(transaction_id,100)) {
    return res.status(400).json({error:"সব ঘর সঠিকভাবে পূরণ করুন।"});
  }
  const t=db.prepare("SELECT * FROM tournaments WHERE id=? AND status='upcoming'").get(Number(tournament_id));
  if (!t) return res.status(400).json({error:"এই টুর্নামেন্টে বুকিং নেওয়া হচ্ছে না।"});
  if (Number(slot_no)<1 || Number(slot_no)>t.total_slots) return res.status(400).json({error:"সঠিক স্লট নির্বাচন করুন।"});
  const bookingCode="FF"+Date.now().toString(36).toUpperCase()+Math.random().toString(36).slice(2,6).toUpperCase();
  try {
    const create=db.transaction(() => {
      const slot=db.prepare("SELECT status FROM slots WHERE tournament_id=? AND slot_no=?").get(t.id,Number(slot_no));
      if (!slot || slot.status!=="available") throw new Error("SLOT_TAKEN");
      db.prepare("UPDATE slots SET status='pending' WHERE tournament_id=? AND slot_no=? AND status='available'").run(t.id,Number(slot_no));
      db.prepare(`INSERT INTO bookings (booking_code,tournament_id,slot_no,player_name,game_uid,contact,payment_method,sender_number,transaction_id)
        VALUES (?,?,?,?,?,?,?,?,?)`).run(bookingCode,t.id,Number(slot_no),player_name.trim(),game_uid.trim(),contact.trim(),payment_method,sender_number.trim(),transaction_id.trim());
    });
    create();
    res.status(201).json({message:"বুকিং জমা হয়েছে। অ্যাডমিন পেমেন্ট যাচাই করার পর নিশ্চিত করবে।",booking_code:bookingCode,status:"pending"});
  } catch(e) {
    if (String(e.message).includes("SLOT_TAKEN") || String(e.code||"").includes("UNIQUE")) return res.status(409).json({error:"দুঃখিত, এই স্লটটি ইতিমধ্যে বুক হয়েছে। অন্য স্লট নির্বাচন করুন।"});
    console.error(e); res.status(500).json({error:"বুকিং জমা দেওয়া যায়নি। আবার চেষ্টা করুন।"});
  }
});
app.post("/api/my-booking", (req,res) => {
  const code=String(req.body.booking_code||"").trim();
  if (!code) return res.status(400).json({error:"বুকিং কোড লিখুন।"});
  const b=db.prepare(`SELECT b.booking_code,b.slot_no,b.player_name,b.status,b.created_at,t.title AS tournament_title
    FROM bookings b JOIN tournaments t ON t.id=b.tournament_id WHERE b.booking_code=?`).get(code);
  if (!b) return res.status(404).json({error:"এই বুকিং কোড পাওয়া যায়নি।"});
  res.json(b);
});

app.post("/api/admin/login", async (req,res) => {
  const {username,password}=req.body||{};
  const expectedUser=process.env.ADMIN_USERNAME||"admin";
  const hash=process.env.ADMIN_PASSWORD_HASH;
  if (!hash || username!==expectedUser || !password || !(await bcrypt.compare(password,hash))) {
    return res.status(401).json({error:"ইউজারনেম বা পাসওয়ার্ড সঠিক নয়; .env সেটিংস যাচাই করুন।"});
  }
  req.session.regenerate(err=>{
    if(err) return res.status(500).json({error:"লগইন করা যায়নি।"});
    req.session.admin=true;
    res.json({message:"লগইন সফল।"});
  });
});
app.post("/api/admin/logout", adminOnly, (req,res)=>req.session.destroy(()=>res.json({message:"লগআউট হয়েছে।"})));
app.get("/api/admin/me",(req,res)=>res.json({logged_in:!!req.session.admin}));
app.get("/api/admin/dashboard",adminOnly,(req,res)=>{
  const stats={
    tournaments:db.prepare("SELECT COUNT(*) n FROM tournaments WHERE status!='hidden'").get().n,
    bookings:db.prepare("SELECT COUNT(*) n FROM bookings").get().n,
    pending:db.prepare("SELECT COUNT(*) n FROM bookings WHERE status='pending'").get().n,
    confirmed:db.prepare("SELECT COUNT(*) n FROM bookings WHERE status='confirmed'").get().n
  };
  const bookings=db.prepare(`SELECT b.*,t.title AS tournament_title,t.entry_fee FROM bookings b JOIN tournaments t ON t.id=b.tournament_id ORDER BY b.id DESC LIMIT 200`).all();
  res.json({stats,bookings,tournaments:db.prepare("SELECT * FROM tournaments ORDER BY id DESC").all(),settings:getSettings()});
});
app.post("/api/admin/bookings/:id/status",adminOnly,(req,res)=>{
  const id=Number(req.params.id), status=req.body.status, note=String(req.body.admin_note||"").slice(0,500);
  if(!["confirmed","rejected","pending"].includes(status)) return res.status(400).json({error:"অবৈধ স্ট্যাটাস।"});
  const b=db.prepare("SELECT * FROM bookings WHERE id=?").get(id);
  if(!b) return res.status(404).json({error:"বুকিং পাওয়া যায়নি।"});
  const update=db.transaction(()=>{
    db.prepare("UPDATE bookings SET status=?,admin_note=? WHERE id=?").run(status,note,id);
    db.prepare("UPDATE slots SET status=? WHERE tournament_id=? AND slot_no=?").run(status==="rejected"?"available":status,b.tournament_id,b.slot_no);
  });
  update(); res.json({message:"বুকিং আপডেট হয়েছে।"});
});
app.post("/api/admin/tournaments",adminOnly,(req,res)=>{
  const x=req.body||{};
  if(!validText(x.title,100)||!validText(x.mode,40)||!Number.isInteger(Number(x.entry_fee))||Number(x.entry_fee)<0||
    !Number.isInteger(Number(x.prize_pool))||Number(x.prize_pool)<0||!validText(x.event_date,30)||
    !Number.isInteger(Number(x.total_slots))||Number(x.total_slots)<1||Number(x.total_slots)>500) return res.status(400).json({error:"টুর্নামেন্টের তথ্য যাচাই করুন।"});
  const id=Number(x.id||0);
  if(id) {
    const old=db.prepare("SELECT * FROM tournaments WHERE id=?").get(id);
    if(!old) return res.status(404).json({error:"টুর্নামেন্ট পাওয়া যায়নি।"});
    const occupied=db.prepare("SELECT MAX(slot_no) m FROM slots WHERE tournament_id=? AND status!='available'").get(id).m||0;
    if(Number(x.total_slots)<occupied) return res.status(400).json({error:"বুক হওয়া স্লটের নম্বরের নিচে মোট স্লট কমানো যাবে না।"});
    const update=db.transaction(()=>{
      db.prepare(`UPDATE tournaments SET title=?,mode=?,entry_fee=?,prize_pool=?,event_date=?,description=?,rules=?,total_slots=?,status=? WHERE id=?`)
        .run(x.title.trim(),x.mode.trim(),Number(x.entry_fee),Number(x.prize_pool),x.event_date,String(x.description||"").slice(0,1000),String(x.rules||"").slice(0,2000),Number(x.total_slots),["upcoming","ongoing","completed","hidden"].includes(x.status)?x.status:"upcoming",id);
      const ins=db.prepare("INSERT OR IGNORE INTO slots(tournament_id,slot_no,status) VALUES(?,?,'available')");
      for(let n=1;n<=Number(x.total_slots);n++) ins.run(id,n);
      db.prepare("DELETE FROM slots WHERE tournament_id=? AND slot_no>? AND status='available'").run(id,Number(x.total_slots));
    }); update();
    return res.json({message:"টুর্নামেন্ট আপডেট হয়েছে।"});
  }
  const create=db.transaction(()=>{
    const r=db.prepare(`INSERT INTO tournaments(title,mode,entry_fee,prize_pool,event_date,description,rules,total_slots,status) VALUES(?,?,?,?,?,?,?,?,?)`)
      .run(x.title.trim(),x.mode.trim(),Number(x.entry_fee),Number(x.prize_pool),x.event_date,String(x.description||"").slice(0,1000),String(x.rules||"").slice(0,2000),Number(x.total_slots),["upcoming","ongoing","completed","hidden"].includes(x.status)?x.status:"upcoming");
    const ins=db.prepare("INSERT INTO slots(tournament_id,slot_no,status) VALUES(?,?,'available')");
    for(let n=1;n<=Number(x.total_slots);n++) ins.run(r.lastInsertRowid,n);
  }); create(); res.status(201).json({message:"নতুন টুর্নামেন্ট তৈরি হয়েছে।"});
});
app.delete("/api/admin/tournaments/:id",adminOnly,(req,res)=>{
  const id=Number(req.params.id);
  const count=db.prepare("SELECT COUNT(*) n FROM bookings WHERE tournament_id=?").get(id).n;
  if(count) {
    db.prepare("UPDATE tournaments SET status='hidden' WHERE id=?").run(id);
    return res.json({message:"এই টুর্নামেন্টে বুকিং আছে, তাই মুছে না দিয়ে লুকানো হয়েছে।"});
  }
  db.prepare("DELETE FROM tournaments WHERE id=?").run(id);
  res.json({message:"টুর্নামেন্ট মুছে ফেলা হয়েছে।"});
});
app.post("/api/admin/settings",adminOnly,(req,res)=>{
  const fields={site_name:100,bkash_number:30,nagad_number:30,notice:500};
  const up=db.prepare("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value");
  for(const [k,max] of Object.entries(fields)) if(typeof req.body[k]==="string") up.run(k,req.body[k].trim().slice(0,max));
  res.json({message:"সেটিংস সেভ হয়েছে।"});
});
app.get("/admin",(req,res)=>res.sendFile(path.join(__dirname,"public","admin.html")));
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log(`FF Tournament running on http://localhost:${PORT}`));
